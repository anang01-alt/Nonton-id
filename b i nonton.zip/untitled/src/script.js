let filmData = [];

function toggleAdmin() {

  const password = prompt("Masukkan kata sandi admin:");

  if (password === "admin123") {

    document.getElementById('adminPanel').style.display = 'block';

  } else {

    alert("Sandi salah!");

  }

}

function addFilm() {

  const title = document.getElementById('filmTitle').value;

  const videoInput = document.getElementById('videoFile');

  const posterInput = document.getElementById('posterFile');

  if (!title || !videoInput.files[0] || !posterInput.files[0]) {

    alert("Semua harus diisi.");

    return;

  }

  const videoURL = URL.createObjectURL(videoInput.files[0]);

  const posterURL = URL.createObjectURL(posterInput.files[0]);

  filmData.push({ title, video: videoURL, poster: posterURL });

  renderFilms();

}

function renderFilms() {

  const container = document.getElementById('filmContainer');

  container.innerHTML = '';

  filmData.forEach((film, index) => {

    const card = document.createElement('div');

    card.className = 'film-card';

    card.innerHTML = `

      <img src="${film.poster}" alt="${film.title}" />

      <p>${film.title}</p>

    `;

    card.onclick = () => playVideo(film.video);

    container.appendChild(card);

  });

}

function playVideo(videoUrl) {

  const modal = document.getElementById('videoModal');

  const player = document.getElementById('videoPlayer');

  player.src = videoUrl;

  modal.style.display = 'flex';

}

function closeVideo() {

  const modal = document.getElementById('videoModal');

  const player = document.getElementById('videoPlayer');

  player.pause();

  player.src = '';

  modal.style.display = 'none';

}